package kg.geektech.game.players;

public interface HavingSuperAbility {
    void applySuperPower(Boss boss, Hero[] heroes);
}
