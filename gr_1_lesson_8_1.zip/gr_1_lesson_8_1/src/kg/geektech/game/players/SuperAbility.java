package kg.geektech.game.players;

public enum SuperAbility {
    HEAL, BOOST, CRITICAL_DAMAGE, SAVE_DAMAGE_AND_REVERT
}
