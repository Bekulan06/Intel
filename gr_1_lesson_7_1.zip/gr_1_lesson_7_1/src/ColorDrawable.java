public interface ColorDrawable extends Drawable {
    void drawWithColor(String color);
}
