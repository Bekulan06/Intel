public class Bus extends Transport {
    @Override
    public void drawWithColor(String color) {
        System.out.println(color + "Автобус" + "\u001B[0m");
    }

    @Override
    public void draw() {
        System.out.println("\uD83D\uDE8C");
    }

    @Override
    public String draw3D(String material) {
        return "Автобус изображен в 3D из материала " + material;
    }
}
