public interface Drawable {
    void draw();

    String draw3D(String material);
}
