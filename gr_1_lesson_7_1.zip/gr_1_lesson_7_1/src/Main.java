public class Main {
    public static void main(String[] args) {
        Animal cat = new Animal() {
            @Override
            public void draw() {
                System.out.println("\uD83D\uDC31");
            }

            @Override
            public String draw3D(String material) {
                return "Кошка изображена в 3D из материала " + material;
            }

            @Override
            public void makeVoice() {
                System.out.println("Мяу");
            }
        };
        cat.makeVoice();
        cat.draw();

        Sparrow sparrow = new Sparrow();
        sparrow.draw();
        System.out.println(sparrow.draw3D("Wood"));
        sparrow.fly();
        sparrow.makeVoice();

        Drawable dog = new Dog();
        // Snake snake = new Snake();
        //         a   = b

        System.out.println("----------");
        Drawable[] drawables = {cat, sparrow,
                new Plane(), dog, new Snake(), new Bus()};
        for (int i = 0; i < drawables.length; i++) {
            drawAll(drawables[i]);
            if (drawables[i] instanceof Animal) {
                ((Animal) drawables[i]).makeVoice();
            }
            if(drawables[i] instanceof Flyable){
                ((Flyable) drawables[i]).fly();
            }
        }

        int a = 8;
        System.out.println((double) a);
        double b = 7.8;
        System.out.println((int) b);
        System.out.println(Math.round(b));
    }

    public static void drawAll(Drawable drawable) {
        drawable.draw();
        System.out.println(drawable.draw3D("Plastic"));
        if(drawable instanceof ColorDrawable){
            ((ColorDrawable) drawable).drawWithColor("\u001B[35m");
        }
    }
}
